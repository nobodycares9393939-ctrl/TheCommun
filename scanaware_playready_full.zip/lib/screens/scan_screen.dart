import 'package:flutter/material.dart';

class ScanScreen extends StatelessWidget {
  const ScanScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ScanAware')),
      body: const Center(child: Text('Scan screen placeholder — integrate app code here.')),
    );
  }
}
