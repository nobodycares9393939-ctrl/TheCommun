import 'package:flutter/material.dart';
import 'screens/scan_screen.dart';

void main() {
  runApp(const MaterialApp(home: ScanScreen()));
}
