# ScanAware Privacy Policy

Effective date: 2025-12-05

ScanAware processes scans locally and does not collect personal data. External API queries (OpenFoodFacts, PubChem, PubMed) are done with product barcodes only.
