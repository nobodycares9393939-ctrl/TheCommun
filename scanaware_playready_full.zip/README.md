ScanAware - Play Store ready scaffold
Package: commun.scanaware
Version: 1.0.1
